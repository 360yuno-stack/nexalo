import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  webpack: (config) => {
    config.resolve.fallback = {
      fs: false,
      net: false,
      tls: false,
    };
    config.externals.push(
      'pino-pretty', 
      'lokijs', 
      'encoding', 
      'accounts'
    );
    return config;
  },
  experimental: {
    turbo: {
      resolveAlias: {
        'accounts': false,
        'pino-pretty': false,
        'lokijs': false,
        'encoding': false,
      }
    }
  }
};

export default nextConfig;
