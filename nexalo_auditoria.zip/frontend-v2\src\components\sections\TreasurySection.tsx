'use client';

export function TreasurySection() {
  return (
    <section id="tesoreria" className="py-20 px-6 relative z-10">
      <div className="max-w-[1400px] mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-[var(--color-primary)] to-[var(--color-accent)]">
            Tesorería Autónoma (Aave & Venus)
          </h2>
          <p className="text-[var(--color-text-secondary)] text-lg max-w-2xl mx-auto">
            El 10% de cada compra se envía a la Tesorería, la cual opera de forma descentralizada inyectando liquidez en protocolos de lending de primer nivel.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* TVL Card */}
          <div className="glass-card p-8 rounded-2xl border border-[var(--color-border-glow)] text-center flex flex-col justify-center relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-br from-[var(--color-primary)]/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <h3 className="text-[var(--color-text-secondary)] font-medium mb-2 relative z-10">Total Value Locked (TVL)</h3>
            <div className="text-5xl font-black text-white mb-2 relative z-10">$142,500.00</div>
            <div className="text-sm text-[var(--color-success)] font-medium flex items-center justify-center gap-1 relative z-10">
              <span className="text-lg">↗</span> +2.4% este mes
            </div>
          </div>

          {/* Aave Strategy Card */}
          <div className="glass-card p-8 rounded-2xl border border-[var(--color-border-glow)] relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
              <span className="text-6xl">👻</span>
            </div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-[#B6509E]/20 flex items-center justify-center">
                <span className="text-xl">👻</span>
              </div>
              <h3 className="text-xl font-bold">Aave v3 Strategy</h3>
            </div>
            <p className="text-sm text-[var(--color-text-secondary)] mb-6">
              Suministro de stablecoins (USDT/USDC) en el mercado de Aave para generar yield constante sin riesgo de impermanent loss.
            </p>
            <div className="flex justify-between items-end">
              <div>
                <div className="text-xs text-[var(--color-text-secondary)] mb-1">APY Promedio</div>
                <div className="text-2xl font-bold text-[#B6509E]">~4.2%</div>
              </div>
              <div className="text-right">
                <div className="text-xs text-[var(--color-text-secondary)] mb-1">Capital Asignado</div>
                <div className="text-lg font-bold text-white">40%</div>
              </div>
            </div>
          </div>

          {/* Venus Strategy Card */}
          <div className="glass-card p-8 rounded-2xl border border-[var(--color-border-glow)] relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
              <span className="text-6xl">🌟</span>
            </div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-[#F5B300]/20 flex items-center justify-center">
                <span className="text-xl">🌟</span>
              </div>
              <h3 className="text-xl font-bold">Venus Protocol</h3>
            </div>
            <p className="text-sm text-[var(--color-text-secondary)] mb-6">
              Yield Optimizer en BSC maximizando retornos mediante suministro sobrecolateralizado en el protocolo nativo de Binance.
            </p>
            <div className="flex justify-between items-end">
              <div>
                <div className="text-xs text-[var(--color-text-secondary)] mb-1">APY Promedio</div>
                <div className="text-2xl font-bold text-[#F5B300]">~6.8%</div>
              </div>
              <div className="text-right">
                <div className="text-xs text-[var(--color-text-secondary)] mb-1">Capital Asignado</div>
                <div className="text-lg font-bold text-white">60%</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
