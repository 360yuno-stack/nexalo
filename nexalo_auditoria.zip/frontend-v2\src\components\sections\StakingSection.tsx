'use client';

import { useUserBalances } from '@/hooks/useNexaloProtocol';
import { TransactionButton } from '@/components/TransactionButton';
import { formatUnits } from 'viem';
import { CONFIG } from '@/lib/config';

export function StakingSection() {
  const { nxlBalance } = useUserBalances();
  
  const formattedNXL = nxlBalance ? formatUnits(nxlBalance as bigint, 18) : '0.00';

  return (
    <section id="staking" className="py-20 px-6 relative z-10 bg-[#0a0a15]">
      <div className="max-w-[1400px] mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-[var(--color-primary)] to-[var(--color-accent)]">
            Staking Institucional
          </h2>
          <p className="text-[var(--color-text-secondary)] text-lg max-w-2xl mx-auto">
            Haz stake de tus tokens NXL para generar ingresos pasivos en WBTC (Bitcoin). Dividendos inyectados automáticamente desde TreasuryBTC.
          </p>
        </div>

        <div className="flex flex-col md:flex-row gap-8 max-w-4xl mx-auto">
          {/* Staking Info Card */}
          <div className="flex-1 glass-card p-8 rounded-2xl border border-[var(--color-border-glow)]">
            <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
              <span className="text-2xl">🏦</span> Tu Bóveda NXL
            </h3>
            
            <div className="space-y-6">
              <div className="flex justify-between items-center p-4 bg-black/40 rounded-xl">
                <span className="text-[var(--color-text-secondary)]">Balance Disponible</span>
                <span className="text-xl font-bold">{parseFloat(formattedNXL).toLocaleString(undefined, {maximumFractionDigits: 2})} NXL</span>
              </div>
              <div className="flex justify-between items-center p-4 bg-black/40 rounded-xl border border-[var(--color-primary)]/30">
                <span className="text-[var(--color-primary)] font-medium">En Stake</span>
                <span className="text-xl font-bold text-[var(--color-primary)]">0.00 NXL</span>
              </div>
              <div className="flex justify-between items-center p-4 bg-black/40 rounded-xl">
                <span className="text-[var(--color-text-secondary)]">Recompensas (WBTC)</span>
                <span className="text-xl font-bold text-[var(--color-accent)]">0.000000 WBTC</span>
              </div>
            </div>
          </div>

          {/* Staking Actions Card */}
          <div className="flex-1 glass-card p-8 rounded-2xl border border-[var(--color-border-glow)] flex flex-col justify-between">
            <div>
              <h3 className="text-xl font-bold mb-2">Operaciones</h3>
              <p className="text-sm text-[var(--color-text-secondary)] mb-6">
                El staking NXL no tiene lock period. Puedes retirar en cualquier momento. Los dividendos WBTC se acumulan por ronda.
              </p>

              <div className="mb-6">
                <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-2">Cantidad a depositar (NXL)</label>
                <div className="relative">
                  <input 
                    type="number" 
                    placeholder="0.00" 
                    className="w-full bg-black/40 border border-white/10 rounded-xl py-3 px-4 text-white focus:outline-none focus:border-[var(--color-primary)] transition-colors"
                  />
                  <button className="absolute right-2 top-2 text-xs bg-[var(--color-primary)]/20 text-[var(--color-primary)] px-2 py-1 rounded font-bold hover:bg-[var(--color-primary)]/40 transition-colors">
                    MAX
                  </button>
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-3">
              <TransactionButton 
                onClick={async () => undefined} // Stub for now, would call useStaking()
                chainIdRequired={CONFIG.NETWORK.chainId}
                successMessage="Staking completado con éxito."
              >
                Depositar Stake
              </TransactionButton>
              <button className="w-full py-3 rounded-xl font-semibold border-2 border-white/10 text-white/70 hover:border-white/30 hover:text-white transition-all">
                Retirar Stake
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
