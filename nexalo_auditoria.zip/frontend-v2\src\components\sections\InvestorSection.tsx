'use client';

export function InvestorSection() {
  return (
    <section id="inversor" className="py-20 px-6 relative z-10 bg-[#0a0a15]">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-14">
          <p className="text-[#F59E0B] font-semibold text-sm uppercase tracking-widest mb-3">Gestión de Capital</p>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Tesorería DeFi & Yield</h2>
          <p className="text-[var(--color-text-secondary)] text-lg max-w-2xl mx-auto">
            Generación de rendimientos pasivos vía protocolos DeFi auditados. Capital gestionado autónomamente por smart contracts.
          </p>
        </div>

        {/* TVL KPIs */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <div className="glass-card rounded-2xl p-6 text-center border border-white/5 hover:border-[var(--color-primary)]/50 transition-colors">
            <div className="w-12 h-12 rounded-xl bg-[var(--color-primary)]/15 flex items-center justify-center mx-auto mb-3">
              💰
            </div>
            <p className="text-xs text-[var(--color-text-secondary)] uppercase tracking-wide mb-2">Total Value Locked</p>
            <p className="text-3xl font-bold text-white">$0.00</p>
            <p className="text-xs text-[var(--color-text-secondary)] mt-2">Sincronizando on-chain...</p>
          </div>
          
          <div className="glass-card rounded-2xl p-6 text-center border border-[var(--color-success)]/30 hover:border-[var(--color-success)] transition-colors scale-105 shadow-[0_10px_30px_rgba(16,185,129,0.1)]">
            <div className="w-12 h-12 rounded-xl bg-[var(--color-success)]/15 flex items-center justify-center mx-auto mb-3">
              📈
            </div>
            <p className="text-xs text-[var(--color-success)] uppercase tracking-wide mb-2 font-semibold">APY Estimado</p>
            <p className="text-3xl font-bold text-white">Dinámico</p>
            <p className="text-xs text-[var(--color-success)] mt-2">Basado en mercado (Aave/AIYield)</p>
          </div>

          <div className="glass-card rounded-2xl p-6 text-center border border-[#F59E0B]/30 hover:border-[#F59E0B] transition-colors">
            <div className="w-12 h-12 rounded-xl bg-[#F59E0B]/15 flex items-center justify-center mx-auto mb-3">
              ✨
            </div>
            <p className="text-xs text-[var(--color-text-secondary)] uppercase tracking-wide mb-2">Rendimiento Generado</p>
            <p className="text-3xl font-bold text-white">$0.00</p>
            <p className="text-xs text-[var(--color-text-secondary)] mt-2">Acumulado total</p>
          </div>
        </div>

        {/* Protocol Integrations */}
        <div className="grid md:grid-cols-2 gap-8">
          {/* Aave */}
          <div className="glass-card rounded-2xl p-8 border-l-4 border-l-[#B6509E] border-t border-r border-b border-white/5">
            <div className="flex justify-between items-start mb-6">
              <div>
                <h3 className="text-xl font-bold text-white mb-1">Aave v3 Integration</h3>
                <p className="text-sm font-medium" style={{color: '#B6509E'}}>Lending Protocol</p>
              </div>
              <span className="text-xs font-semibold px-3 py-1 rounded-full" style={{background: 'rgba(182,80,158,0.15)', color: '#B6509E', border: '1px solid rgba(182,80,158,0.3)'}}>ACTIVO</span>
            </div>
            <p className="text-[var(--color-text-secondary)] text-sm mb-6 leading-relaxed">
              El 40% de la tesorería se deposita automáticamente en Aave para generar rendimientos estables sobre USDC/USDT.
            </p>
            <div className="space-y-3">
              <div className="flex justify-between border-b border-white/5 pb-2">
                <span className="text-[var(--color-text-secondary)] text-sm">Capital Asignado</span>
                <span className="text-white font-semibold text-sm">40% del TVL</span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-2">
                <span className="text-[var(--color-text-secondary)] text-sm">Current APY</span>
                <span className="font-semibold text-sm" style={{color: '#B6509E'}}>~4.2%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--color-text-secondary)] text-sm">Estrategia</span>
                <span className="text-white font-semibold text-sm">Supply USDT/USDC</span>
              </div>
            </div>
          </div>

          {/* AIYield */}
          <div className="glass-card rounded-2xl p-8 border-l-4 border-l-[#38BDF8] border-t border-r border-b border-white/5">
            <div className="flex justify-between items-start mb-6">
              <div>
                <h3 className="text-xl font-bold text-white mb-1">AIYield Optimizer</h3>
                <p className="text-sm font-medium" style={{color: '#38BDF8'}}>Algorithmic Farming</p>
              </div>
              <span className="text-xs font-semibold px-3 py-1 rounded-full" style={{background: 'rgba(56,189,248,0.15)', color: '#38BDF8', border: '1px solid rgba(56,189,248,0.3)'}}>ACTIVO</span>
            </div>
            <p className="text-[var(--color-text-secondary)] text-sm mb-6 leading-relaxed">
              El 60% de la tesorería utiliza AIYield para encontrar las pools de liquidez más eficientes en BSC, rebalanceando automáticamente.
            </p>
            <div className="space-y-3">
              <div className="flex justify-between border-b border-white/5 pb-2">
                <span className="text-[var(--color-text-secondary)] text-sm">Capital Asignado</span>
                <span className="text-white font-semibold text-sm">60% del TVL</span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-2">
                <span className="text-[var(--color-text-secondary)] text-sm">Current APY</span>
                <span className="font-semibold text-sm" style={{color: '#38BDF8'}}>~11.3%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--color-text-secondary)] text-sm">Estrategia</span>
                <span className="text-white font-semibold text-sm">Multi-pool LP</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
