'use client';

import { useState, useEffect } from 'react';
import { useAccount } from 'wagmi';
import { useUserBalances } from '@/hooks/useNexaloProtocol';

export function AccountSection() {
  const [mounted, setMounted] = useState(false);
  const { address, isConnected } = useAccount();
  const { usdtBalance, nxlBalance } = useUserBalances();

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted || !isConnected) {
    return null;
  }

  return (
    <section id="account" className="py-20 px-6 relative z-10 bg-[#080B12]">
      <div className="max-w-[1400px] mx-auto">
        <div className="text-center mb-16">
          <p className="text-[var(--color-primary)] font-semibold text-sm uppercase tracking-widest mb-3">Tu Panel</p>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Mi Cuenta</h2>
          <p className="text-[var(--color-text-secondary)] text-lg max-w-2xl mx-auto">
            Gestiona tus tickets, premios y recompensas en NXL en un solo lugar.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* User Profile Card */}
          <div className="glass-card rounded-2xl p-8 border border-[var(--color-border-glow)]">
            <h3 className="text-xl font-bold mb-6">Información de Billetera</h3>
            
            <div className="space-y-4">
              <div className="bg-black/40 rounded-xl p-4 border border-white/5">
                <p className="text-[var(--color-text-secondary)] text-sm mb-1">Billetera Conectada</p>
                <p className="font-mono text-[var(--color-primary)] font-bold break-all">
                  {address}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-black/40 rounded-xl p-4 border border-[var(--color-success)]/30">
                  <p className="text-[var(--color-text-secondary)] text-sm mb-1">Balance USDT</p>
                  <p className="text-2xl font-bold text-[var(--color-success)]">
                    {usdtBalance ? (Number(usdtBalance) / 1e18).toFixed(2) : '0.00'}
                  </p>
                </div>
                <div className="bg-black/40 rounded-xl p-4 border border-[var(--color-primary)]/30">
                  <p className="text-[var(--color-text-secondary)] text-sm mb-1">Balance NXL</p>
                  <p className="text-2xl font-bold text-[var(--color-primary)]">
                    {nxlBalance ? (Number(nxlBalance) / 1e18).toFixed(2) : '0.00'}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Activity / Rewards Card */}
          <div className="glass-card rounded-2xl p-8 border border-[var(--color-border-glow)] flex flex-col justify-between">
            <div>
              <h3 className="text-xl font-bold mb-6">Tus Recompensas</h3>
              <p className="text-sm text-[var(--color-text-secondary)] mb-6">
                Aquí podrás reclamar tus premios ganados en rondas finalizadas y comisiones de referidos.
              </p>

              <div className="bg-black/40 rounded-xl p-4 border border-white/5 flex justify-between items-center mb-4">
                <span className="text-[var(--color-text-secondary)]">Reclamable (USDT)</span>
                <span className="text-2xl font-bold text-white">0.00</span>
              </div>
            </div>

            <button className="w-full bg-white/10 text-white/50 cursor-not-allowed py-4 rounded-xl font-bold transition-all">
              Nada que reclamar por ahora
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
