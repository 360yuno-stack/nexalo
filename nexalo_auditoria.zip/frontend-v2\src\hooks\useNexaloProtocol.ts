'use client';

import { useReadContract, useWriteContract, useAccount, useReadContracts } from 'wagmi';
import { CONFIG } from '@/lib/config';
import { ABIS } from '@/lib/abis';

export function useProtocolState() {
  const { data: globalStopped, isLoading: isLoadingStopped } = useReadContract({
    address: CONFIG.CONTRACTS.NEXUM_MANAGER,
    abi: ABIS.NEXUM_MANAGER,
    functionName: 'globalStopped',
  });

  const { data: paused, isLoading: isLoadingPaused } = useReadContract({
    address: CONFIG.CONTRACTS.NEXUM_MANAGER,
    abi: ABIS.NEXUM_MANAGER,
    functionName: 'paused',
  });

  return {
    globalStopped,
    paused,
    isLoading: isLoadingStopped || isLoadingPaused,
  };
}

export function useUserBalances() {
  const { address } = useAccount();

  const { data, refetch, isLoading } = useReadContracts({
    contracts: [
      {
        address: CONFIG.CONTRACTS.USDT,
        abi: ABIS.NXL_TOKEN, // Generic ERC20 ABI works for USDT balanceOf
        functionName: 'balanceOf',
        args: [address ?? '0x0000000000000000000000000000000000000000'],
      },
      {
        address: CONFIG.CONTRACTS.NXL_TOKEN,
        abi: ABIS.NXL_TOKEN,
        functionName: 'balanceOf',
        args: [address ?? '0x0000000000000000000000000000000000000000'],
      }
    ],
    query: {
      enabled: !!address,
    }
  });

  return {
    usdtBalance: data?.[0]?.result,
    nxlBalance: data?.[1]?.result,
    refetch,
    isLoading,
  };
}

export function useBuyTicket() {
  const { writeContractAsync, isPending } = useWriteContract();

  const buySpecific = async (productId: number, ticketNumbers: bigint[], referrer: string) => {
    return await writeContractAsync({
      address: CONFIG.CONTRACTS.NEXUM_MANAGER,
      abi: ABIS.NEXUM_MANAGER,
      functionName: 'buySpecificTickets',
      args: [BigInt(productId), ticketNumbers, referrer as `0x${string}`],
    });
  };

  const buyRandom = async (productId: number, quantity: number, referrer: string) => {
    return await writeContractAsync({
      address: CONFIG.CONTRACTS.NEXUM_MANAGER,
      abi: ABIS.NEXUM_MANAGER,
      functionName: 'buyTickets',
      args: [BigInt(productId), BigInt(quantity), referrer as `0x${string}`],
    });
  };

  return {
    buySpecific,
    buyRandom,
    isPending,
  };
}

export function useApproveUSDT() {
  const { writeContractAsync, isPending } = useWriteContract();
  
  const approve = async (amount: bigint) => {
    return await writeContractAsync({
      address: CONFIG.CONTRACTS.USDT,
      abi: ABIS.NXL_TOKEN, // using standard ERC20 approve
      functionName: 'approve',
      args: [CONFIG.CONTRACTS.NEXUM_MANAGER, amount],
    });
  };

  return { approve, isPending };
}
