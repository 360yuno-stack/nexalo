'use client';

import { useState } from 'react';
import { CONFIG } from '@/lib/config';
import { useBuyTicket, useApproveUSDT, useUserBalances } from '@/hooks/useNexaloProtocol';
import { TransactionButton } from '@/components/TransactionButton';
import { parseUnits } from 'viem';
import { useAccount, useReadContract } from 'wagmi';
import { ABIS } from '@/lib/abis';

export function NexumGrid() {
  const { buyRandom } = useBuyTicket();
  const { approve } = useApproveUSDT();
  const { address } = useAccount();
  const { usdtBalance } = useUserBalances();

  // Selected product state
  const [selectedProductId, setSelectedProductId] = useState<number>(0);
  const [quantity, setQuantity] = useState<number>(1);
  const selectedProduct = CONFIG.PRODUCTS.find(p => p.id === selectedProductId) || CONFIG.PRODUCTS[0];

  // Read allowance
  const { data: allowance, refetch: refetchAllowance } = useReadContract({
    address: CONFIG.CONTRACTS.USDT,
    abi: ABIS.NXL_TOKEN, // Standard ERC20 allowance
    functionName: 'allowance',
    args: [address ?? '0x0000000000000000000000000000000000000000', CONFIG.CONTRACTS.NEXUM_MANAGER],
    query: { enabled: !!address }
  });

  const totalCostUSD = selectedProduct.price * quantity;
  const totalCostRaw = parseUnits(totalCostUSD.toString(), 18);
  const needsApproval = allowance === undefined || (allowance as bigint) < totalCostRaw;

  // Handler for buying
  const handleBuy = async () => {
    if (usdtBalance !== undefined && (usdtBalance as bigint) < totalCostRaw) {
      throw new Error("Saldo insuficiente de USDT");
    }
    if (allowance === undefined || (allowance as bigint) < totalCostRaw) {
      throw new Error("Debes aprobar USDT primero");
    }

    // In a real environment, we'd get the referrer from local storage
    const referrer = '0x0000000000000000000000000000000000000000';
    return await buyRandom(selectedProduct.id, quantity, referrer);
  };

  const handleApprove = async () => {
    const hash = await approve(totalCostRaw);
    if (hash) {
      // Force refetch allowance so the button switches to "Buy"
      setTimeout(() => refetchAllowance(), 2000); 
    }
    return hash;
  };

  return (
    <section id="comprar" className="py-20 px-6 relative z-10">
      <div className="max-w-[1400px] mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-[var(--color-primary)] to-[var(--color-accent)]">
            Ecosistema de Nexums
          </h2>
          <p className="text-[var(--color-text-secondary)] text-lg max-w-2xl mx-auto">
            Elige el producto que mejor se adapte a tu perfil de riesgo. Todos los Nexums garantizan recompensas en NXL y un 96% de distribución.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6 mb-12">
          {CONFIG.PRODUCTS.map((product) => (
            <div 
              key={product.id}
              onClick={() => setSelectedProductId(product.id)}
              className={`glass-card cursor-pointer p-6 rounded-2xl flex flex-col items-center text-center transition-all ${selectedProductId === product.id ? 'border-[var(--color-primary)] bg-[var(--color-card-hover)] scale-105 shadow-[0_10px_30px_rgba(99,102,241,0.2)]' : 'hover:scale-105'}`}
            >
              <div className="text-4xl mb-4">{product.emoji}</div>
              <h3 className="text-xl font-bold mb-2">{product.name}</h3>
              <div className="text-2xl font-black text-[var(--color-success)] mb-4">${product.price} <span className="text-sm text-[var(--color-text-secondary)] font-normal">USDT</span></div>
              
              <div className="w-full text-sm text-[var(--color-text-secondary)] space-y-2 mb-4">
                <div className="flex justify-between">
                  <span>Jackpot:</span>
                  <span className="font-bold text-white">${product.jackpot.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Recompensa:</span>
                  <span className="font-bold text-[var(--color-primary)]">+{product.nxlPerTicket} NXL</span>
                </div>
                <div className="flex justify-between">
                  <span>Formato:</span>
                  <span>{product.digits} Dígitos</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Purchase Interface */}
        <div className="max-w-3xl mx-auto glass-card rounded-2xl p-8 border border-[var(--color-border-glow)]">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="flex-1 w-full">
              <h3 className="text-2xl font-bold mb-2">Comprar {selectedProduct.name} {selectedProduct.emoji}</h3>
              <p className="text-[var(--color-text-secondary)] mb-6">Selecciona la cantidad de tickets que deseas adquirir. Recibirás recompensas instantáneas en NXL.</p>
              
              <div className="flex items-center gap-4 mb-6">
                {[1, 3, 5, 10].map(num => (
                  <button 
                    key={num}
                    onClick={() => setQuantity(num)}
                    className={`px-4 py-2 rounded-lg font-medium transition-colors ${quantity === num ? 'bg-[var(--color-primary)] text-white' : 'bg-white/5 hover:bg-white/10 text-[var(--color-text-secondary)]'}`}
                  >
                    x{num}
                  </button>
                ))}
              </div>
              
              <div className="flex items-center justify-between p-4 bg-black/40 rounded-xl mb-6">
                <span className="text-[var(--color-text-secondary)]">Total a Pagar:</span>
                <span className="text-2xl font-bold">${totalCostUSD.toLocaleString()} USDT</span>
              </div>
            </div>

            <div className="w-full md:w-auto flex flex-col gap-4">
              {usdtBalance !== undefined && (usdtBalance as bigint) < totalCostRaw ? (
                <button disabled className="bg-red-500/20 text-red-500 font-bold px-6 py-3 rounded-xl border border-red-500/50 cursor-not-allowed">
                  Saldo Insuficiente
                </button>
              ) : needsApproval ? (
                <TransactionButton 
                  onClick={handleApprove} 
                  chainIdRequired={CONFIG.NETWORK.chainId}
                  successMessage="USDT Aprobado. Ahora puedes confirmar la compra."
                >
                  1. Aprobar USDT
                </TransactionButton>
              ) : (
                <TransactionButton 
                  onClick={handleBuy} 
                  chainIdRequired={CONFIG.NETWORK.chainId}
                  successMessage={`¡Compra exitosa! Recibiste ${(selectedProduct.nxlPerTicket * quantity).toFixed(2)} NXL.`}
                >
                  Confirmar Compra
                </TransactionButton>
              )}
              <p className="text-xs text-center text-[var(--color-text-secondary)]">
                Contrato Autónomo Verificado <br/> {CONFIG.NETWORK.chainName}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
