import { Header } from '@/components/layout/Header';
import { DashboardTabs } from '@/components/layout/DashboardTabs';
import { ArrowRight, ShieldCheck } from 'lucide-react';

export default function Home() {
  return (
    <main className="min-h-screen">
      <Header />

      {/* Main App Content - Tabbed Interface */}
      <div className="pt-32">
        <DashboardTabs />
      </div>
    </main>
  );
}
