'use client';

import { useState, useRef, useEffect } from 'react';
import { CONFIG } from '@/lib/config';

export function FAQSection() {
  const [messages, setMessages] = useState<{role: 'bot' | 'user', text: string}[]>([
    { role: 'bot', text: '¡Hola! Soy el asistente de NEXALO. Puedo responder tus preguntas sobre el protocolo, cómo comprar tickets, cómo funciona el VRF, NXL tokens y más. ¿En qué puedo ayudarte?' }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const chatRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatRef.current) {
      chatRef.current.scrollTop = chatRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = () => {
    if (!inputText.trim()) return;
    
    setMessages(prev => [...prev, { role: 'user', text: inputText }]);
    const currentInput = inputText;
    setInputText('');
    setIsTyping(true);

    setTimeout(() => {
      let response = "No encontré una respuesta exacta. Puedes preguntarme sobre:\n\n• Comprar tickets y elegir números\n• Premios y sorteos (Chainlink VRF)\n• Token NXL y staking\n• Inversión y pools de liquidez\n• Referidos y embajadores\n• Seguridad del protocolo";
      
      const lower = currentInput.toLowerCase();
      if (lower.includes('comprar') || lower.includes('ticket')) {
        response = "1) Conecta tu wallet. 2) Asegúrate de tener USDT en BSC. 3) Elige un Nexum. 4) Usa los botones de compra rápida o selecciona números manualmente.";
      } else if (lower.includes('vrf') || lower.includes('ganador')) {
        response = "El ganador se selecciona mediante Chainlink VRF (Verifiable Random Function), un oráculo de aleatoriedad criptográficamente verificable. Nadie puede predecir o manipular el resultado.";
      } else if (lower.includes('precio') || lower.includes('costo')) {
        response = "FLASH: $1 USDT\nORIGINAL: $1 USDT\nPREMIUM: $20 USDT\nELITE: $10 USDT\nVIP: $200 USDT\nBLACKBLOK: $200 USDT";
      } else if (lower.includes('nxl')) {
        response = "NXL es el token de gobernanza y utilidad de NEXALO. Recibes NXL como recompensa al comprar tickets. Puedes hacer staking de NXL para recibir WBTC.";
      }
      
      setMessages(prev => [...prev, { role: 'bot', text: response }]);
      setIsTyping(false);
    }, 1000);
  };

  return (
    <section id="faq" className="py-20 px-6 relative z-10 bg-[#080B12]">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-14">
          <p className="text-[var(--color-primary)] font-semibold text-sm uppercase tracking-widest mb-3">Soporte</p>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Preguntas Frecuentes</h2>
          <p className="text-[var(--color-text-secondary)] text-lg max-w-2xl mx-auto">
            ¿Tienes dudas? Escríbenos directamente o consulta a nuestro Bot Autónomo.
          </p>
        </div>

        {/* Chat */}
        <div className="glass-card rounded-2xl overflow-hidden border border-[var(--color-border-glow)]">
          <div className="px-6 py-4 border-b border-white/5 flex items-center gap-3 bg-gradient-to-r from-[var(--color-primary)]/10 to-transparent">
            <div className="w-3 h-3 rounded-full bg-[var(--color-success)] animate-pulse"></div>
            <span className="font-bold text-white text-sm">NEXALO ASSISTANT</span>
            <span className="ml-auto text-xs text-[var(--color-text-secondary)]">Respuestas instantáneas</span>
          </div>

          <div ref={chatRef} className="h-80 overflow-y-auto p-6 space-y-4">
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : ''}`}>
                {msg.role === 'bot' && (
                  <div className="w-8 h-8 rounded-xl bg-[var(--color-primary)]/15 border border-[var(--color-primary)]/20 flex items-center justify-center flex-shrink-0">
                    🤖
                  </div>
                )}
                <div className={`${msg.role === 'bot' ? 'bg-[var(--color-primary)]/10 rounded-tl-none border-[var(--color-primary)]/20' : 'bg-white/5 rounded-tr-none border-white/10'} border rounded-2xl px-4 py-3 max-w-[80%]`}>
                  <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
                  <p className="text-[0.65rem] opacity-50 mt-1">{msg.role === 'bot' ? 'NEXALO Bot' : 'Tú'}</p>
                </div>
                {msg.role === 'user' && (
                  <div className="w-8 h-8 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center flex-shrink-0 text-sm">
                    👤
                  </div>
                )}
              </div>
            ))}
            {isTyping && (
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-xl bg-[var(--color-primary)]/15 border border-[var(--color-primary)]/20 flex items-center justify-center flex-shrink-0">
                  🤖
                </div>
                <div className="bg-[var(--color-primary)]/10 border border-[var(--color-primary)]/20 rounded-2xl rounded-tl-none px-4 py-3">
                  <span className="inline-flex gap-1 items-center h-full">
                    <span className="w-2 h-2 bg-[var(--color-primary)]/60 rounded-full animate-bounce" style={{animationDelay: '0ms'}}></span>
                    <span className="w-2 h-2 bg-[var(--color-primary)]/60 rounded-full animate-bounce" style={{animationDelay: '150ms'}}></span>
                    <span className="w-2 h-2 bg-[var(--color-primary)]/60 rounded-full animate-bounce" style={{animationDelay: '300ms'}}></span>
                  </span>
                </div>
              </div>
            )}
          </div>

          <div className="px-6 pb-6 pt-2">
            <div className="flex gap-3">
              <input 
                type="text" 
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Escribe tu pregunta..." 
                className="flex-1 bg-white/5 border border-white/10 text-white rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[var(--color-primary)]/50 transition-colors"
              />
              <button 
                onClick={handleSend}
                className="bg-[var(--color-primary)] text-white px-5 py-3 rounded-xl text-sm font-semibold hover:opacity-90 transition-opacity"
              >
                ENVIAR
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
